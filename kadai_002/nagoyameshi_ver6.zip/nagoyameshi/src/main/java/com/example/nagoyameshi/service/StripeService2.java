//package com.example.nagoyameshi.service;
//
//import java.util.Map;
//import java.util.Optional;
//
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Service;
//
//import com.example.nagoyameshi.form.ReservationRegisterForm;
//import com.stripe.Stripe;
//import com.stripe.exception.StripeException;
//import com.stripe.model.Event;
//import com.stripe.model.StripeObject;
//import com.stripe.model.checkout.Session;
//import com.stripe.param.checkout.SessionCreateParams;
//import com.stripe.param.checkout.SessionRetrieveParams;
//
//import jakarta.servlet.http.HttpServletRequest;
//
//@Service
//public class StripeService2 {
//    @Value("${stripe.api-key}")
//    private String stripeApiKey;
//    
//  @Value("${stripe.premium-plan-id}")    
//    private String stripePremiumPlanId;
//
//    private final ReservationService reservationService;
//    
//    public StripeService2(ReservationService reservationService) {
//        this.reservationService = reservationService;
//    }    
//    
//    // Set your secret key. Remember to switch to your live secret key in production.
//    // See your keys here: https://dashboard.stripe.com/apikeys
//    // セッションを作成し、Stripeに必要な情報を返す
//    public String createStripeSession(String shopName, ReservationRegisterForm reservationRegisterForm, HttpServletRequest httpServletRequest) {
//    Stripe.apiKey = stripeApiKey;
//
//	// The price ID passed from the client
//	//   String priceId = request.queryParams("priceId");
//	String priceId = stripePremiumPlanId;
//	
//    String requestUrl = new String(httpServletRequest.getRequestURL());
//
//	SessionCreateParams params =
//			SessionCreateParams.builder()
//            .addPaymentMethodType(SessionCreateParams.PaymentMethodType.CARD)
//        
//        .setMode(SessionCreateParams.Mode.PAYMENT)
//        .setSuccessUrl(requestUrl.replaceAll("/shops/[0-9]+/reservations/confirm", "") + "/reservations?reserved")
//        .setCancelUrl(requestUrl.replace("/reservations/confirm", ""))
//        
//        .setPaymentIntentData(
//                SessionCreateParams.PaymentIntentData.builder()
//                    .putMetadata("userId", reservationRegisterForm.getUserId().toString())
//                    .build())
//        
//		.setMode(SessionCreateParams.Mode.SUBSCRIPTION)
//		.addLineItem(new SessionCreateParams.LineItem.Builder()
//		// For metered billing, do not pass quantity
//		.setQuantity(1L)
//		.setPrice(priceId)
//		.build()
//				)
//		.build();
//
//		try {
//			Session session = Session.create(params);
//			return session.getId();
//		} catch (StripeException e) {
//			e.printStackTrace();
//			return "";
//		}
//        
//    }
//
//    // セッションから予約情報を取得し、ReservationServiceクラスを介してデータベースに登録する  
//    public void processSessionCompleted(Event event) {
//        Optional<StripeObject> optionalStripeObject = event.getDataObjectDeserializer().getObject();
//        optionalStripeObject.ifPresent(stripeObject -> {
//            Session session = (Session)stripeObject;
//            SessionRetrieveParams params = SessionRetrieveParams.builder().addExpand("payment_intent").build();
//
//            try {
//                session = Session.retrieve(session.getId(), params, null);
//                Map<String, String> paymentIntentObject = session.getPaymentIntentObject().getMetadata();
//                reservationService.create(paymentIntentObject);
//            } catch (StripeException e) {
//                e.printStackTrace();
//            }
//        });
//    }    
//
//}
