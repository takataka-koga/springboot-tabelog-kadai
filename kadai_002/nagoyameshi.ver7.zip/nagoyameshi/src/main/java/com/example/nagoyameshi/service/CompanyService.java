package com.example.nagoyameshi.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.nagoyameshi.entity.Company;
import com.example.nagoyameshi.form.CompanyEditForm;
import com.example.nagoyameshi.repository.CompanyRepository;

@Service
public class CompanyService {
    private final CompanyRepository companyRepository;    
    
    public CompanyService(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;        
    }    

    @Transactional
    public void update(CompanyEditForm companyEditForm) {
        Company company = companyRepository.getReferenceById(companyEditForm.getId());
                
        company.setName(companyEditForm.getName());                
        company.setRepresentative(companyEditForm.getRepresentative());                
        company.setBuildDay(companyEditForm.getBuildDay());                
        company.setPostalCode(companyEditForm.getPostalCode());
        company.setAddress(companyEditForm.getAddress());
        company.setDescription(companyEditForm.getDescription());

                    
        companyRepository.save(company);
    }    

}
