 let maxDate = new Date();
 maxDate = maxDate.setMonth(maxDate.getMonth() + 3);
 
 flatpickr('#fromReservationDate', {
   enableTime: true,
   dateFormat: "Y-m-d",
   locale: 'ja',
   minDate: 'today',
   maxDate: maxDate
 });
