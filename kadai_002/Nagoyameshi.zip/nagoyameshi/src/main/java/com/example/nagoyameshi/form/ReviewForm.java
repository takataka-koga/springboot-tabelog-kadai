package com.example.nagoyameshi.form;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ReviewForm {
	
    @NotBlank(message = "レビューを入力してください。")
    @Size(min = 1, max = 5, message = "1～5の間で入力してください。")
    private Integer ster;
            
    @NotBlank(message = "コメントを入力してください。")
    private String reviews_comment;   
    
}
