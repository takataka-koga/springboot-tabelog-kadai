package com.example.nagoyameshi.controller;

public class AdminCategoryController {

}
