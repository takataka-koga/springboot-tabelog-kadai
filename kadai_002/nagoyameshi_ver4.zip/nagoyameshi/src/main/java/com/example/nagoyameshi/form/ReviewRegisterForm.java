package com.example.nagoyameshi.form;

import org.hibernate.validator.constraints.Length;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class ReviewRegisterForm {
	
    @NotBlank(message = "評価を入力してください。")
    @Size(min = 1, max = 5, message = "評価は1～5の間で入力してください。")
    private Integer ster;
            
    @NotBlank(message = "コメントを入力してください。")
    @Length(max = 300, message = "コメントは300文字以内で入力してください。")
    private String reviews_comment;   
    
}
