 const stripe = Stripe('pk_test_51Oe5liCw14WnEJmoA6nTgpF3v7Txx33UVapB2EU7DHzHwikpGoxo5udQCu8McEGRs35RLkDJsiTaNrbd9Nrlk1OA00kyw3Xn4b');
 const paymentButton = document.querySelector('#paymentButton');
 
 paymentButton.addEventListener('click', () => {
   stripe.redirectToCheckout({
     sessionId: sessionId
   })
 });
